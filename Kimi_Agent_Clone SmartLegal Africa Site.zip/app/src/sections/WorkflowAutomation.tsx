import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

export function WorkflowAutomation() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Decorative Element */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative hidden lg:flex items-center justify-center order-2 lg:order-1"
          >
            <div className="relative w-80 h-80">
              {/* Workflow Diagram Visualization */}
              <div className="absolute inset-0 flex items-center justify-center">
                {/* Central Node */}
                <div className="absolute w-20 h-20 rounded-full bg-primary flex items-center justify-center z-10">
                  <span className="text-white text-xl font-bold">1</span>
                </div>
                
                {/* Connected Nodes */}
                <motion.div
                  initial={{ opacity: 0, x: -60 }}
                  whileInView={{ opacity: 1, x: -80 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                  className="absolute w-16 h-16 rounded-full bg-secondary flex items-center justify-center"
                >
                  <span className="text-white text-lg font-bold">2</span>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, x: 60 }}
                  whileInView={{ opacity: 1, x: 80 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                  className="absolute w-16 h-16 rounded-full bg-secondary flex items-center justify-center"
                >
                  <span className="text-white text-lg font-bold">3</span>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, y: 60 }}
                  whileInView={{ opacity: 1, y: 80 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.5 }}
                  className="absolute w-16 h-16 rounded-full bg-secondary flex items-center justify-center"
                >
                  <span className="text-white text-lg font-bold">4</span>
                </motion.div>
                
                {/* Connection Lines (SVG) */}
                <svg className="absolute inset-0 w-full h-full" viewBox="0 0 320 320">
                  <motion.line
                    x1="160"
                    y1="160"
                    x2="80"
                    y2="160"
                    stroke="#00A0B0"
                    strokeWidth="2"
                    strokeDasharray="5,5"
                    initial={{ pathLength: 0 }}
                    whileInView={{ pathLength: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.3 }}
                  />
                  <motion.line
                    x1="160"
                    y1="160"
                    x2="240"
                    y2="160"
                    stroke="#00A0B0"
                    strokeWidth="2"
                    strokeDasharray="5,5"
                    initial={{ pathLength: 0 }}
                    whileInView={{ pathLength: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.4 }}
                  />
                  <motion.line
                    x1="160"
                    y1="160"
                    x2="160"
                    y2="240"
                    stroke="#00A0B0"
                    strokeWidth="2"
                    strokeDasharray="5,5"
                    initial={{ pathLength: 0 }}
                    whileInView={{ pathLength: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.5 }}
                  />
                </svg>
              </div>
              
              {/* Background Glow */}
              <div className="absolute inset-0 rounded-full bg-primary/5 blur-3xl" />
            </div>
          </motion.div>

          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="order-1 lg:order-2"
          >
            <span className="inline-block text-xs font-semibold tracking-wider text-secondary uppercase mb-4">
              Workflow Automation
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Ultimate experiences
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Workflows are important to define repeated processes and guide you through 
              the process step-by-step. They give you information about pending and completed 
              tasks related to each matter. Prioritise all the tasks, set deadlines and 
              reminders to increase your work efficiency and productivity levels.
            </p>
            <Button
              className="bg-primary hover:bg-primary-dark text-white rounded-full px-8 py-6 text-base font-medium transition-all duration-200 hover:scale-[1.02] hover:shadow-lg"
            >
              Sign Up
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
