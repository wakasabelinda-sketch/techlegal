import { motion } from 'framer-motion';
import { Phone, Calculator, UserX, ArrowRight } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface AdditionalFeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  href: string;
  index: number;
}

function AdditionalFeatureCard({ icon: Icon, title, description, href, index }: AdditionalFeatureCardProps) {
  return (
    <motion.a
      href={href}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{
        duration: 0.5,
        delay: index * 0.1,
        ease: [0.4, 0, 0.2, 1],
      }}
      whileHover={{ y: -4 }}
      className="group block bg-white rounded-xl p-6 border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300"
    >
      <div className="flex items-start gap-4">
        {/* Icon */}
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors duration-300">
          <Icon className="w-6 h-6 text-primary" strokeWidth={1.5} />
        </div>
        
        {/* Content */}
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-primary transition-colors duration-200">
            {title}
          </h3>
          <p className="text-sm text-gray-600 leading-relaxed mb-3">
            {description}
          </p>
          <span className="inline-flex items-center text-sm font-medium text-primary group-hover:gap-2 transition-all duration-200">
            Learn More
            <ArrowRight className="w-4 h-4 ml-1 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-200" />
          </span>
        </div>
      </div>
    </motion.a>
  );
}

const additionalFeatures = [
  {
    icon: Phone,
    title: 'Virtual Call Center',
    description: 'Direct your office line to the system. Handle all inbound & outbound calls from the system.',
    href: '#virtual-call-center',
  },
  {
    icon: Calculator,
    title: 'Legal Accounting',
    description: 'Legal Accounting brings precision, efficiency, and ease to your financial operations.',
    href: '#legal-accounting',
  },
  {
    icon: UserX,
    title: 'Leave Management',
    description: 'Ensure continuous productivity with automated task reassignment, flexible leave policies, and powerful analytics for informed HR and management decisions.',
    href: '#leave-management',
  },
];

export function AdditionalFeatures() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {additionalFeatures.map((feature, index) => (
            <AdditionalFeatureCard
              key={feature.title}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              href={feature.href}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
