import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

interface CTASectionProps {
  title: string;
  description: string;
  buttonText: string;
  variant?: 'default' | 'gradient';
}

export function CTASection({ 
  title, 
  description, 
  buttonText, 
  variant = 'default' 
}: CTASectionProps) {
  const isGradient = variant === 'gradient';

  return (
    <section className={`py-20 ${isGradient ? 'bg-gradient-to-r from-primary to-primary-light' : 'bg-white'}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className={`text-3xl sm:text-4xl font-bold mb-6 ${isGradient ? 'text-white' : 'text-gray-900'}`}>
            {title}
          </h2>
          <p className={`text-lg mb-8 max-w-2xl mx-auto leading-relaxed ${isGradient ? 'text-white/90' : 'text-gray-600'}`}>
            {description}
          </p>
          <Button
            className={`rounded-full px-8 py-6 text-base font-medium transition-all duration-200 hover:scale-[1.02] hover:shadow-lg ${
              isGradient 
                ? 'bg-white text-primary hover:bg-gray-100' 
                : 'bg-primary text-white hover:bg-primary-dark'
            }`}
          >
            {buttonText}
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
