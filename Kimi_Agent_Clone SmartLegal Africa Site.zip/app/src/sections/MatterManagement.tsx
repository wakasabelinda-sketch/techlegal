import { motion } from 'framer-motion';
import { Bell, TrendingUp, Globe } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface FeatureItemProps {
  icon: LucideIcon;
  title: string;
  description: string;
  index: number;
}

function FeatureItem({ icon: Icon, title, description, index }: FeatureItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{
        duration: 0.5,
        delay: index * 0.1,
        ease: [0.4, 0, 0.2, 1],
      }}
      className="flex gap-4"
    >
      <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center flex-shrink-0">
        <Icon className="w-5 h-5 text-secondary" strokeWidth={1.5} />
      </div>
      <div>
        <h4 className="font-semibold text-gray-900 mb-1">{title}</h4>
        <p className="text-sm text-gray-600 leading-relaxed">{description}</p>
      </div>
    </motion.div>
  );
}

const features = [
  {
    icon: Bell,
    title: 'Reminders',
    description: 'Get things done on time without missing any deadline by receiving automatic email notifications of important dates before they arrive.',
  },
  {
    icon: TrendingUp,
    title: 'Track case progress',
    description: 'It helps teams work better and more efficiently. You can track information about where the case is and identify what needs to be done.',
  },
  {
    icon: Globe,
    title: 'Access anywhere, anytime',
    description: 'Gone are the days of paper trails and heavy client files. Take your tablet to a court or your meetings and access all records online.',
  },
];

export function MatterManagement() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Legal matter management
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Stay organised and manage clients, legal matters, documents, attendance notes, 
              email & phone logs, fees etc with ease.
            </p>
            
            {/* Feature List */}
            <div className="space-y-6">
              {features.map((feature, index) => (
                <FeatureItem
                  key={feature.title}
                  icon={feature.icon}
                  title={feature.title}
                  description={feature.description}
                  index={index}
                />
              ))}
            </div>
          </motion.div>

          {/* Decorative Element */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative hidden lg:flex items-center justify-center"
          >
            <div className="relative w-80 h-80">
              {/* Decorative Circles */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/20 to-primary-light/20" />
              <div className="absolute inset-8 rounded-full bg-gradient-to-br from-primary/30 to-primary-light/30" />
              <div className="absolute inset-16 rounded-full bg-gradient-to-br from-primary/40 to-primary-light/40 flex items-center justify-center">
                <div className="w-24 h-24 rounded-full bg-primary flex items-center justify-center">
                  <span className="text-white text-3xl font-bold">SL</span>
                </div>
              </div>
              
              {/* Floating Elements */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -top-4 right-8 w-16 h-16 rounded-full bg-secondary/20"
              />
              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -bottom-4 left-8 w-12 h-12 rounded-full bg-primary/20"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
