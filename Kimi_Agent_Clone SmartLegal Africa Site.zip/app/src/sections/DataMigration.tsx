import { motion } from 'framer-motion';
import { Database } from 'lucide-react';

export function DataMigration() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left"
        >
          <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center flex-shrink-0">
            <Database className="w-6 h-6 text-secondary" strokeWidth={1.5} />
          </div>
          <div>
            <h3 className="text-xl font-semibold text-gray-900 mb-1">
              Data Migration
            </h3>
            <p className="text-gray-600">
              Import your clients and matters in seconds. Start using the system immediately.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
