import { motion } from 'framer-motion';
import { 
  Users, 
  Briefcase, 
  FileText, 
  Workflow, 
  FolderOpen, 
  Calendar 
} from 'lucide-react';
import { FeatureCard } from '@/components/FeatureCard';

const features = [
  {
    icon: Users,
    title: 'Client Management',
    description: 'Keep track of all your client details like name, number, address, email, notes, tasks, events, invoices, payments, and more.',
  },
  {
    icon: Briefcase,
    title: 'Case Management',
    description: 'Manage your legal matters more efficiently and you can access client\'s entire case file from anywhere at any time.',
  },
  {
    icon: FileText,
    title: 'Client Billing',
    description: 'A comprehensive invoice management module for all your invoicing needs. Create an invoice in seconds and send in PDF format.',
  },
  {
    icon: Workflow,
    title: 'Workflow Automation',
    description: 'Define processes for your team and actually get things done on time without missing deadlines.',
  },
  {
    icon: FolderOpen,
    title: 'Documents Management',
    description: 'Store legal documents separately for each matter in a searchable location. Custom templates to speed up process.',
  },
  {
    icon: Calendar,
    title: 'Legal Calendaring',
    description: 'Stay current on all matter events and deadlines. Once you create an event in the calendar, see that specific matter and access the entire matter.',
  },
];

export function FeaturesGrid() {
  return (
    <section id="how-it-works" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 bg-secondary/10 text-secondary text-xs font-semibold tracking-wider uppercase rounded-full mb-4">
            At a Glance
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
            How it Works
          </h2>
        </motion.div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <FeatureCard
              key={feature.title}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
