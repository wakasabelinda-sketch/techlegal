import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.3,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: [0.4, 0, 0.2, 1] as const,
    },
  },
};

const imageVariants = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.6,
      delay: 0.4,
      ease: [0.4, 0, 0.2, 1] as const,
    },
  },
};

export function HeroSection() {
  return (
    <section className="relative min-h-screen overflow-hidden">
      {/* Gradient Background with Curve */}
      <div className="absolute inset-0">
        {/* Main gradient background */}
        <div 
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(135deg, #9C1C6B 0%, #D4A5C3 100%)',
          }}
        />
        
        {/* Curved SVG Shape */}
        <svg
          className="absolute bottom-0 left-0 w-full h-auto"
          viewBox="0 0 1440 400"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
        >
          <path
            d="M0 400L1440 400L1440 100C1440 100 1200 0 720 0C240 0 0 100 0 100L0 400Z"
            fill="white"
          />
        </svg>

        {/* Additional curve for smoother transition */}
        <svg
          className="absolute bottom-0 left-0 w-full h-auto"
          viewBox="0 0 1440 320"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
        >
          <path
            d="M0 320L1440 320L1440 150C1440 150 1200 50 720 50C240 50 0 150 0 150L0 320Z"
            fill="white"
            fillOpacity="0.95"
          />
        </svg>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-48">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="text-left"
          >
            <motion.h1
              variants={itemVariants}
              className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight"
            >
              Manage Matters
              <br />
              <span className="text-primary">Efficiently.</span> Grow
              <br />
              your Business.
            </motion.h1>
            
            <motion.p
              variants={itemVariants}
              className="mt-6 text-lg text-gray-700 max-w-xl leading-relaxed"
            >
              We help you manage legal matters efficiently, enhance client satisfaction, 
              and increase profitability by streamlining legal processes through Smart Legal Africa, 
              a cloud-based legal management system. Say goodbye to scattered workflows and manual tasks.
            </motion.p>
            
            <motion.div variants={itemVariants} className="mt-8">
              <Button
                className="bg-primary hover:bg-primary-dark text-white rounded-full px-8 py-6 text-base font-medium transition-all duration-200 hover:scale-[1.02] hover:shadow-lg"
              >
                Sign Up
              </Button>
            </motion.div>
          </motion.div>

          {/* Hero Image */}
          <motion.div
            variants={imageVariants}
            initial="hidden"
            animate="visible"
            className="relative flex justify-center lg:justify-end"
          >
            <div className="relative w-80 h-80 sm:w-96 sm:h-96 lg:w-[450px] lg:h-[450px]">
              {/* Circular Image Container */}
              <div className="w-full h-full rounded-full overflow-hidden border-8 border-white/30 shadow-2xl">
                <img
                  src="/images/hero-image.jpg"
                  alt="Legal professionals"
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Decorative Elements */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-white/20 rounded-full blur-xl" />
              <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-primary/20 rounded-full blur-2xl" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
