import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { HeroSection } from '@/sections/HeroSection';
import { FeaturesGrid } from '@/sections/FeaturesGrid';
import { AdditionalFeatures } from '@/sections/AdditionalFeatures';
import { DataMigration } from '@/sections/DataMigration';
import { CTASection } from '@/sections/CTASection';
import { MatterManagement } from '@/sections/MatterManagement';
import { WorkflowAutomation } from '@/sections/WorkflowAutomation';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <HeroSection />
        
        <FeaturesGrid />
        
        <AdditionalFeatures />
        
        <DataMigration />
        
        <CTASection
          title="Give it a Try"
          description="Are you tired of juggling multiple tasks, documents, and deadlines? Let our legal management software take care of the heavy lifting for you. Sign up today and experience the convenience of a centralized platform that streamlines your legal practice."
          buttonText="Sign Up"
        />
        
        <MatterManagement />
        
        <WorkflowAutomation />
      </main>
      
      <Footer />
    </div>
  );
}

export default App;
